package dev.lpa;

public enum CrimeType {

    DRINKANDDRIVE,MURDER,SUICIDE,BLACKMAIL,OTHER
}
