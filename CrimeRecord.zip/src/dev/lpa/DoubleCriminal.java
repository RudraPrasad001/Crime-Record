package dev.lpa;

public class DoubleCriminal extends Criminal{
    public DoubleCriminal(String name, CrimeType crimeType,CrimeType secondCrime) {
        super(name, crimeType,secondCrime);
    }

}
